/*	Joshua Graham
	 *  ID: 11490893
	 *  ITC-313
	 * 	Date:04/10/2013
	 *  Assignment 2
	 *  Task 1
	 *  This Software manages a database of student marks by interacting with MySQL
	 */
import java.sql.DriverManager; //import some functions from the mysql driver jar file
import java.sql.ResultSet;
import java.sql.SQLException;

public class Task1 { //name of java file

	public static void main(String[] args) { //program start running here
		System.out.print("Initialising Database... ");  //a useful display that setup is running (aka Please wait), print is used to nest command is printed on same line
		setup(); //run the setup method to create  database and tables with dummy data
		System.out.println("Done!\n"); //feedback to user that database setup is complete, \n is newline
		boolean running = true; //a variable to keep us informed if the user wishes to continue using program
		java.util.Scanner inputScanner = new java.util.Scanner(System.in); //create a scanner to get input
		String choiceString; //a variable to store user input
		boolean error = false; //assume no error but track it
		int choice = 0; //variable for the menu
		while (running){ //if running is true, run the program
			while ((error == true) || (choice < 1 || choice > 4)){ //if no error and input is in range, keep running
				System.out.println("Task 1 - Assignment 2 - ITC313 - Joshua Graham - 11490893\n"); //title
				System.out.println("+++++++++++++++++++++++++++++");
				System.out.println("+++++ Marker Management +++++");
				System.out.println("+++++++++++++++++++++++++++++\n"); // \n means input newline
				System.out.println("Please make a selection:");
				System.out.println("1: Display All Marks");
				System.out.println("2: Search Marks");
				System.out.println("3: Insert a Mark");
				System.out.println("4: Exit");
				choiceString = inputScanner.nextLine(); //get user input 
				try {
					choice = Integer.parseInt(choiceString); //convert input to a number
				} catch (NumberFormatException e) { //catch a user input error and give feedback
				      error = true; //not an number
				      System.out.println("Not a Choice! Enter it again:");
				}
			}
			switch(choice){
			case 1: DoDatabase("query", "select * from Student_marks_ITC000;"); //send type and statement to be executed in another method
					System.out.println(""); //new line
					System.out.println("Press enter to return to menu:"); //ask user return to menu when satisfied
					choiceString = inputScanner.nextLine();
					choice = 0; //back to menu, (number is outside range and will tiger the main while loop (2nd one)
					break;
			case 2:	System.out.println(""); //new line
					System.out.println("Type a ID to search by:");
					choiceString = inputScanner.nextLine(); //get user input
					DoDatabase("query", "select * from Student_marks_ITC000 where student_id = "+choiceString+";"); //send the statement with the user query
					System.out.println("\nPress enter to return to menu:");
					choiceString = inputScanner.nextLine(); //press enter to continue
					choice = 0; //back to menu
					break;
			case 3:	System.out.println("");
					System.out.print("Insert a Mark choosen. Follow the prompts to enter a mark.\n");
					System.out.print("Student ID:");
					String choiceID = inputScanner.nextLine();	//get user input for the marks
					System.out.println("");
					System.out.print("Name:");
					String choiceName = inputScanner.nextLine();
					System.out.println("");
					System.out.print("Assignment 1:");
					String choiceAssign1 = inputScanner.nextLine();
					System.out.println("");
					System.out.print("Assignment 2:");
					String choiceAssign2 = inputScanner.nextLine();
					System.out.println("");
					System.out.print("Assignment 3:");
					String choiceAssign3 = inputScanner.nextLine();
					System.out.println("");
					System.out.print("Final Exam:");
					String choiceExam = inputScanner.nextLine();
					System.out.print("\nImporting Data... ");	//begin entering data into system
					DoDatabase("update", "INSERT INTO `Student_marks_ITC000` VALUES ("+choiceID+",'"+choiceName+"',"+choiceAssign1+
							", "+choiceAssign2+", "+choiceAssign3+", "+choiceExam+");"); //do update database and with this statement
					System.out.println("Done!"); //user feedback
					System.out.println("The entry is as follows:\n"); //double user feedback
					DoDatabase("query", "select * from Student_marks_ITC000 where student_id = "+choiceID+";");
					System.out.println("\nPress enter to return to menu:"); //enter to return to menu
					choiceString = inputScanner.nextLine();
					choice = 0; //back to menu
					break;
			case 4:	System.out.println("Exit choosen. Thankyou for using Marker Management");
					inputScanner.close(); //begin closing things; - scanner
					running = false; //stop while loop (if next statement fails)
					System.exit(0); //stop program  with 0 meaning no error
			}
		}		
	}
	public static int calcFinal(int[] input) { //here are calculate the overall mark
		int assign1 = input[0] / 10;//10% - weight of marks
		int assign2 = input[1] / 5;//20%
		int assign3 = input[2] / 5;//20%
		int exam = input[3] / 2;//50%
		int overallFinal = assign1 + assign2 + assign3 + exam; //combine to get 100%
		return overallFinal; //give back the program
		}
	public static void DoDatabase(String type, String queryString){
		try {
			//database setup
			Class.forName("com.mysql.jdbc.Driver"); //connect to driver
			java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/st11490893","root","abc123"); //make connection (db, username, password)
			java.sql.Statement statement=connection.createStatement(); //create a statement object from connection
			if (type.equals("query")){ // perform a something based on type
				System.out.println("Overall is calculated as: assign1: 10% assign2 20% assign 3: 20% exam 50%\n"); //reveal weights
				System.out.println("ID: \t Name \t\t Assign1 \t Assign2 \t Assign3 \t Exam \t Overall:"); //table titles simulated, /t is a tab (large space)
				ResultSet resultSet = statement.executeQuery(queryString); //get result to variable
		        while (resultSet.next()) { //loop through and compare
		        int[] marks = {Integer.parseInt(resultSet.getString(3)),Integer.parseInt(resultSet.getString(4)),Integer.parseInt(resultSet.getString(5)),Integer.parseInt(resultSet.getString(6))};
		        System.out.println(resultSet.getString(1)+"\t"+resultSet.getString(2)+"\t"+resultSet.getString(3)+"\t\t"+
		        		resultSet.getString(4)+"\t\t"+resultSet.getString(5)+"\t\t"+resultSet.getString(6)+"\t"+calcFinal(marks));
		        	//get marks to calcFinal and print all to a table like layout
		        }
			}else{ //update
				statement.executeUpdate(queryString);	//straight add data to database	
			}
	        connection.close(); //finish and back to home page
		} catch (SQLException e) { //print the errors if any for debugging
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			}
	}
	public static void setup(){ //first commnd run from main, setups up database
		try {
			//database setup
			Class.forName("com.mysql.jdbc.Driver");
			java.sql.Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","abc123");
			java.sql.Statement statement=connection.createStatement();
			//see if database exists already
			ResultSet resultSet = connection.getMetaData().getCatalogs(); //return table of databases
			boolean exists = false;
	        while (resultSet.next()) { //loop through and compare
	          String databaseName = resultSet.getString(1);
	            if(databaseName.equals("st11490893")){ //search of this db name
	                exists = true;
	            }
	        }
	        resultSet.close();
	        if (exists == false){ //if not exist, create it
	        	statement.executeUpdate("create database st11490893;");
	        } //no error handing is done here, due to time and make the both ITC313 and ITC357 compatible even if error appear.
	        statement.executeUpdate("use st11490893;");		////though error only appear if one the assignments are run twice
	        statement.executeUpdate("create table Student_marks_ITC000(student_id int NOT NULL, name char(30), assignment_1 int, "+
	        		"assignment_2 int, assignment_3 int, final INT, PRIMARY KEY(student_id));");
	        statement.addBatch("INSERT INTO `Student_marks_ITC000` VALUES (101,'Bill Graham',85, 60, 90, 78);");
	        statement.addBatch("INSERT INTO `Student_marks_ITC000` VALUES (102,'Victoria King',74, 54, 78, 97);");
	        statement.addBatch("INSERT INTO `Student_marks_ITC000` VALUES (103,'Sarah Boch',75, 57, 89, 98);");
	  		statement.addBatch("INSERT INTO `Student_marks_ITC000` VALUES (104,'Chris Fang',53, 54, 95, 84);");
	        statement.addBatch("INSERT INTO `Student_marks_ITC000` VALUES (106,'Mellisa Meyer',85, 60, 90, 78);");
	        statement.addBatch("INSERT INTO `Student_marks_ITC000` VALUES (107,'Joseph Super',90, 56, 77, 82);");
	        statement.executeBatch(); //batch used to quick insertion of data to database, all at once
	        connection.close(); //finish and back to home page
		} catch (SQLException e) { //print some the error that come for debugging
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}

