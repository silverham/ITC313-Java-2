/*	Joshua Graham
	 *  ID: 11490893
	 *  ITC-313
	 * 	Date:04/10/2013
	 *  Assignment 2
	 *  Task 2
	 *  The Software practises Multithreading by during loading and keylistener actions
	 */
import javax.swing.*;		//enables use of Jlabels and other GUI elements
import java.util.concurrent.ExecutorService; //load things needed for concurrent usage
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.awt.*;			//GUI layouts
import java.awt.event.*;	//GUI Buttons

@SuppressWarnings("serial") //stops IDE eclipse from complaining about serial 
public class Task2 extends JFrame{
	//make the things are going to use
	//static because there are many classes and we need to refer to same variable/objects
	static int maxHieghtScrollbar = 300; //max height(value) of scollbar, used later to stop us go to high
	static JScrollBar scrollbar1 = new JScrollBar(JScrollBar.VERTICAL, 250, 50, 0, maxHieghtScrollbar);
	static JScrollBar scrollbar2 = new JScrollBar(JScrollBar.VERTICAL, 250, 50, 0, maxHieghtScrollbar);
	static JScrollBar scrollbar3 = new JScrollBar(JScrollBar.VERTICAL, 250, 50, 0, maxHieghtScrollbar);
	static JScrollBar scrollbar4 = new JScrollBar(JScrollBar.VERTICAL, 250, 50, 0, maxHieghtScrollbar);
	static int speed1; //these keep keep of the speed we are maintaining
	static int speed2;
	static int speed3;
	static int speed4 = 0;
	static JLabel label1 = new JLabel(); //the speed texts
	static JLabel label2 = new JLabel();
	static JLabel label3 = new JLabel();
	static JLabel label4 = new JLabel();
	static JLabel lblInstructions = new JLabel(); //the instructions text
	static JPanel panel1 = new JPanel(); // the 5 panel used
	static JPanel panel2 = new JPanel();
	static JPanel panel3 = new JPanel();
	static JPanel panel4 = new JPanel();
	static JPanel panel5 = new JPanel();
	//these, panel are all loaded at same time.
	public static class setupPanel1 implements Runnable { //Runnable makes it threadable
	    public void run() { //run is need to be used in threads
	    	//setup panel 1
	    	JLabel carTitle = new JLabel(); //new label for title
	    	carTitle.setText("--Car 1--"); //set Test of title
			label1.setText(String.valueOf("Speed: "+speed1)); //set inital text data
			panel1.setLayout(new BorderLayout()); //set layout
			panel1.add(scrollbar1, BorderLayout.EAST); //add scroll to the right  (also makes it small)
			panel1.add(label1, BorderLayout.CENTER); //add to the first panel and the text goes on the centre
			panel1.add(carTitle, BorderLayout.NORTH); //add the title to the top
	    }
	  }
	//another panel loaded at same time
	public static class setupPanel2 implements Runnable { //Runnable = threadable
	    public void run() { //Runnable = needs run
	    	//setup panel 2
	    	JLabel carTitle = new JLabel();
	    	carTitle.setText("--Car 2--"); 
			label2.setText("Speed: "+speed2);       //Initial setup data (refer to setupPanel2 for explanation)
			panel2.setLayout(new BorderLayout());
			panel2.add(scrollbar2, BorderLayout.EAST);
			panel2.add(label2, BorderLayout.CENTER);
			panel2.add(carTitle, BorderLayout.NORTH);
	    }
	}
	    	
	public static class setupPanel3 implements Runnable { //Runnable-threaded
		public void run() { //called by thread
			//setup panel 3
			JLabel carTitle = new JLabel();
	    	carTitle.setText("--Car 3--"); 
			label3.setText("Speed: "+speed3);//Initial setup data (refer to setupPanel2 for explanation)
			panel3.setLayout(new BorderLayout());
			panel3.add(scrollbar3, BorderLayout.EAST);
			panel3.add(label3, BorderLayout.CENTER);
			panel3.add(carTitle, BorderLayout.NORTH);
	    }
	}
	public static class setupPanel4 implements Runnable { //runnable by thread caller
	     public void run() {
	    	//setup panel 4
	    	 JLabel carTitle = new JLabel();
		    carTitle.setText("--Car 4--"); 
	 		label4.setText("Speed: "+speed4);//Initial setup data (refer to setupPanel2 for explanation)
	 		panel4.setLayout(new BorderLayout());
	 		panel4.add(scrollbar4, BorderLayout.EAST);
	 		panel4.add(label4, BorderLayout.CENTER);
	 		panel4.add(carTitle, BorderLayout.NORTH);
	     }
	}
	public static class setupPanel5 implements Runnable {
	     public void run() {
	    	//setup panel 5
	 		lblInstructions.setText("<html>"+	//here are instructions, html is used for layout
	 								"Keyboard keys:<br />"+ //<br /> means newline
	 								"car 1: 1- up, 2- down<br />"+
	 								"car 2: 3- up, 4- down<br />"+
	 								"car 3: 5- up, 6- down<br />"+
	 								"car 4: 7- up, 8- down<br />"+
	 								"Note:<br />"+
	 								"Numpad not work.</html>");
	 		panel5.add(lblInstructions); //add above text to panel 5
	     }
	}
	
	Task2(){ //main program and is an object
		ExecutorService executor = Executors.newFixedThreadPool(5); //create 5 threads to used
	    executor.execute(new setupPanel1());  //use each thread made above with a task
	    executor.execute(new setupPanel2());
	    executor.execute(new setupPanel3());
	    executor.execute(new setupPanel4());
	    executor.execute(new setupPanel5());
	    executor.shutdown(); //close the executor (thread creator) when threads finish by themselves
	    try { 
	    	executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS); //wait until panels have been made
	    	} catch (InterruptedException e) { //catch any error that my come and printo to screen
	    	  System.out.println(e); //error occurred
	    	}
	    //setup panel 5
   	 	setLayout(new GridLayout(1,5, 5, 5)); //set main program layout, 1 row, 5columns 
   	 	add(panel1);							//and 5 padding both sides, horizontal and vertical spaces
   	 	add(panel2);
		add(panel3);	//add each made panel to the frame (main program)
		add(panel4);
		add(panel5);
		setTitle("Multi-threading Cars - Task 2 - Assignment 2 - ITC313 - Joshua Graham - 11490893"); //set title of program
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //make the close button quit.
		setSize(600, 160); 	//a rectanglar small size for small screens and looks good
		setLocationRelativeTo(null); //center the program on screen
		setVisible(true);	//done setting up, now to display
		setFocusable(true); //sometimes program does not focus, we fix it here
		this.addKeyListener(new mylistener1()); //use one thread(?) for all listeners
		this.addKeyListener(new mylistener2());	//each listenes will create 
		this.addKeyListener(new mylistener3()); //another thread of its own to do the actual stuff
		this.addKeyListener(new mylistener4());    
	}
	//carMove's classes are the actual code that do things in the program
	public class carMove1 implements Runnable{ //Runnable is threadable
		private String key; //store the key pressed
		carMove1(String key){ //key is transferred he from key listener
			this.key = key;
		}
		@Override
		public void run() { //the starting point when run by thread maker
			if(key.equals("1")){ //if its the lower key
				if (speed1 < maxHieghtScrollbar){ //but speed is already not too high
					speed1 += 20;	//increase by 20 - just enough to see scrollbar move
				}
			}else if (key.equals("2")){ //if it's the higher key
				if (speed1 > 0){ //not too low
					speed1 -= 20;	//decrease by 20
				}
			}
			scrollbar1.setValue(maxHieghtScrollbar -speed1); //display new speed on scrollbar (minus (-) here becase we display from bottom up (bottom is zero)
			label1.setText(String.valueOf("Speed: "+speed1));  //display the new speed on a lablel
		}
		
	}
	public class carMove2 implements Runnable{ //a threadable class
		private String key;			//see specifc explanation above(carMove1) for each thing does
		carMove2(String key){
			this.key = key; //stores key value
		}
		@Override
		public void run() {
			if(key.equals("3")){	//sets the new speed according to it being higher or lower
				if (speed2 < maxHieghtScrollbar){
					speed2 += 20;	
				}
			}else if (key.equals("4")){
				if (speed2 > 0){
					speed2 -= 20;	
				}
			}
			scrollbar2.setValue(maxHieghtScrollbar -speed2); //minus(-) is beacse scollbar bottom should be zero
			label2.setText(String.valueOf("Speed: "+speed2));
		}
	}
	public class carMove3 implements Runnable{ //threaded
		private String key;//see specifc explanation above(carMove1) for each thing does
		carMove3(String key){
			this.key = key; //stores key value
		}
		@Override
		public void run() {	//change the speed
			if(key.equals("5")){
				if (speed3 < maxHieghtScrollbar){
					speed3 += 20;			//set new speed
				}
			}else if (key.equals("6")){
				if (speed3 > 0){
					speed3 -= 20;	
				}
			}
			scrollbar3.setValue(maxHieghtScrollbar -speed3); //change display
			label3.setText(String.valueOf("Speed: "+speed3));
		}
	}
	public class carMove4 implements Runnable{
		private String key;//see specifc explanation above(carMove1) for each thing does
		carMove4(String key){
			this.key = key; //store key value
		}
		@Override
		public void run() { //run by thread
			if(key.equals("7")){
				if (speed4 < maxHieghtScrollbar){  //if within range, set new speed
					speed4 += 20;	
				}
			}else if (key.equals("8")){
				if (speed4 > 0){
					speed4 -= 20;	
				}
			}
			scrollbar4.setValue(maxHieghtScrollbar -speed4); //display new speed
			label4.setText(String.valueOf("Speed: "+speed4));
		}
	}

	public class mylistener1 extends KeyAdapter implements KeyListener{ //these are run on key press
		public void keyPressed(KeyEvent e){	//when key is pressed (pushed down)
			String key = KeyEvent.getKeyText(e.getKeyCode()); //assign keyboard value to string
			Runnable carMove1 = new carMove1(key); //make runnable instance of the carMove1 and pass it the key value
			Thread thread1 = new Thread(carMove1); //assign the instance to a thread 
			thread1.start(); //now start the thread
			
		}
	}
	public class mylistener2 extends KeyAdapter implements KeyListener{ //run my keypress
		public void keyPressed(KeyEvent e){		//see mylistener1 for specifics
			String key = KeyEvent.getKeyText(e.getKeyCode()); //get string value
			Runnable carMove2 = new carMove2(key);
			Thread thread2 = new Thread(carMove2);	//make thread to change value
			thread2.start();
			
		}
	}
	public class mylistener3 extends KeyAdapter implements KeyListener{
		public void keyPressed(KeyEvent e){	//see mylistener1 for specifics
			String key = KeyEvent.getKeyText(e.getKeyCode()); //get string value
			Runnable carMove3 = new carMove3(key);
			Thread thread3 = new Thread(carMove3);	//make thread and run it
			thread3.start();
			
		}
	}
	public class mylistener4 extends KeyAdapter implements KeyListener{ //run on key press
		public void keyPressed(KeyEvent e){	//see mylistener1 for specifics
			String key = KeyEvent.getKeyText(e.getKeyCode()); //store value of key
			Runnable carMove4 = new carMove4(key);
			Thread thread4 = new Thread(carMove4);	//make thread and run to the change speed
			thread4.start();
			
		}
	}
	public static void main(String[] args) throws Exception {
		new Task2(); //instantiate instance of program
		}

}

